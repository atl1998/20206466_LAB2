package com.example.lab2_20206466.model;

import java.awt.*;

public class Foto {
    private Color[][] tablacolores;

    public Foto(Color[][] tablacolores) {
        this.tablacolores = tablacolores;
    }


}
