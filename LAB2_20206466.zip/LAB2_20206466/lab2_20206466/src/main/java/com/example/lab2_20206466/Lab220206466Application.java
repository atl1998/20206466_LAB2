package com.example.lab2_20206466;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab220206466Application {

    public static void main(String[] args) {
        SpringApplication.run(Lab220206466Application.class, args);
    }

}
