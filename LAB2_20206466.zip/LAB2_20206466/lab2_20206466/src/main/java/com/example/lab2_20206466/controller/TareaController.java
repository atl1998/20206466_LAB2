package com.example.lab2_20206466.controller;
import org.springframework.ui.Model;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.awt.*;
import java.util.ArrayList;
/*controller para gestionar los controladores*/
@Controller
public class TareaController {

    /*creamos una lista afuera de los metodos*/
    private ArrayList<Color[][]> listaFotos=new ArrayList<>();
    private ArrayList<Integer> listaCantFotos = new ArrayList();

    @GetMapping("/patito_hule")
    public String paginaPrincipal(){
        return "formulario";
    }


    @PostMapping("/ejecutar")
    public String guardarPersona(@RequestParam("filas") String filasParcela,
                                 @RequestParam("columnas") String columnasParcela,
                                 @RequestParam("posicion") String posicionPatos,
                                 @RequestParam("numfotos") String cantFotos){

        /*lista con la cantidad de fotos*/
        for (int i = 0; i < Integer.parseInt(cantFotos); i++) {
            listaCantFotos.add(i);
        }


        /*colores de la parcela*/
        Color colorParcela=new Color(0, 217, 255);
        Color colorPato=new Color(229, 198, 24);

        /*indicar posiciones de los patos, ejm de ingreso de datos (5 como maximo): 5,4 3,4 1,2 2,0 3,0*/
        String[] posiciones = columnasParcela.split(" ");
        String posicion1=posiciones[0];
        String posicion2=posiciones[1];
        String posicion3=posiciones[2];
        String posicion4=posiciones[3];
        String posicion5=posiciones[4];
        int p1x=Integer.parseInt(posicion1.split(",")[0]);
        int p1y=Integer.parseInt(posicion1.split(",")[1]);
        int p2x=Integer.parseInt(posicion2.split(",")[0]);
        int p2y=Integer.parseInt(posicion2.split(",")[1]);
        int p3x=Integer.parseInt(posicion3.split(",")[0]);
        int p3y=Integer.parseInt(posicion3.split(",")[1]);
        int p4x=Integer.parseInt(posicion4.split(",")[0]);
        int p4y=Integer.parseInt(posicion4.split(",")[1]);
        int p5x=Integer.parseInt(posicion5.split(",")[0]);
        int p5y=Integer.parseInt(posicion5.split(",")[1]);

        /*crear primera tabla*/
        int filas= Integer.parseInt(filasParcela);
        int columnas= Integer.parseInt(columnasParcela);
        Color[][] parcela = new Color[filas][columnas];
        for (int x=0; x < filas; x++) {
            for (int y=0; y < columnas; y++){
                if(x==p1x||x==p2x||x==p3x||x==p4x||x==p5x){
                    if(y==p1y||y==p2y||y==p3y||y==p4y||y==p5y){
                        parcela[x][y]=colorPato;
                    }else{
                        parcela[x][y]=colorParcela;
                    }
                }
            }
        }
        /*modificacion de la tabla*/
        /*logica que va por el arreglo buscando patos*/
        for(int w=0; w < Integer.parseInt(cantFotos); w++){
            for (int x=0; x < filas; x++) {
                for (int y=0; y < columnas; y++){
                    /*logica que determina la cantidad de patos vecinos*/
                    int numPatosVecinos=0;
                    if(x>1&&y>1){
                        if(parcela[x+1][y+1]==colorPato){
                            numPatosVecinos+=1;
                        }
                        if(parcela[x+1][y]==colorPato){
                            numPatosVecinos+=1;
                        }
                        if(parcela[x+1][y-1]==colorPato){
                            numPatosVecinos+=1;
                        }
                        if(parcela[x][y+1]==colorPato){
                            numPatosVecinos+=1;
                        }
                        if(parcela[x][y-1]==colorPato){
                            numPatosVecinos+=1;
                        }
                        if(parcela[x-1][y+1]==colorPato){
                            numPatosVecinos+=1;
                        }
                        if(parcela[x-1][y]==colorPato){
                            numPatosVecinos+=1;
                        }
                        if(parcela[x-1][y-1]==colorPato){
                            numPatosVecinos+=1;
                        }
                    }
                    if(x>1&&y==0){
                        if(parcela[x+1][y+1]==colorPato){
                            numPatosVecinos+=1;
                        }
                        if(parcela[x+1][y]==colorPato){
                            numPatosVecinos+=1;
                        }
                        if(parcela[x][y+1]==colorPato){
                            numPatosVecinos+=1;
                        }
                        if(parcela[x-1][y+1]==colorPato){
                            numPatosVecinos+=1;
                        }
                        if(parcela[x-1][y]==colorPato){
                            numPatosVecinos+=1;
                        }

                    }
                    if(y>1&&x==0){
                        if(parcela[x+1][y+1]==colorPato){
                            numPatosVecinos+=1;
                        }
                        if(parcela[x+1][y]==colorPato){
                            numPatosVecinos+=1;
                        }
                        if(parcela[x+1][y-1]==colorPato){
                            numPatosVecinos+=1;
                        }
                        if(parcela[x][y+1]==colorPato){
                            numPatosVecinos+=1;
                        }
                        if(parcela[x][y-1]==colorPato){
                            numPatosVecinos+=1;
                        }
                    }
                    if(x==0&&y==0){
                        if(parcela[x+1][y+1]==colorPato){
                            numPatosVecinos+=1;
                        }
                        if(parcela[x+1][y]==colorPato){
                            numPatosVecinos+=1;
                        }
                        if(parcela[x][y+1]==colorPato){
                            numPatosVecinos+=1;
                        }

                    }
                    if (x==filas&&y==columnas){
                        if(parcela[x][y-1]==colorPato){
                            numPatosVecinos+=1;
                        }
                        if(parcela[x-1][y]==colorPato){
                            numPatosVecinos+=1;
                        }
                        if(parcela[x-1][y-1]==colorPato){
                            numPatosVecinos+=1;
                        }
                    }

                    /*cambiamos el color dependiendo de los patos vecinos*/
                    if(numPatosVecinos==3){
                        parcela[x][y]=colorPato;
                    }
                    if(numPatosVecinos<2||numPatosVecinos>3){
                        parcela[x][y]=colorParcela;
                    }



                }
            }
            /*lista que añade las fotos tomadas*/
            listaFotos.add(parcela);

        }

        /*Mostramos los datos en la consola*/
        System.out.println("filas: "+filasParcela+"\n"+
                        "columnas: "+columnasParcela+"\n"+
                        "posicion: "+posicionPatos+"\n"+
                        "numfotos: "+cantFotos+"\n");

        return "redirect:/listaFotos";

    }

    /*utilizamos el objeto model para enviar la informacion de los formularios a la lista*/
    @GetMapping("/listaFotos")
    public String listaFotos(Model model){
        model.addAttribute("listacantFotos",listaCantFotos);
        model.addAttribute("listaFotos",listaFotos);
        return "patolandia";
    }

}

