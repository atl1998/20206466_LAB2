package com.example.lab2_20206466;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab220206466ApplicationTests {

    @Test
    void contextLoads() {
    }

}
